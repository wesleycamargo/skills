# sdlc-create-intent

This portable agent skill turns an informal software-change request into `sdlc/<work-item>/intent.md` for user review. It intentionally stops before specification, architecture, planning, or implementation.

## How to use

Ask a compatible agent: “Use `sdlc-create-intent` to capture an intent for [idea or issue].” Review and approve the resulting `intent.md` before starting `sdlc-create-spec`.

The canonical skill instructions are in `SKILL.md`. The ZIP bundle contains this skill only. Packaging it as an Agent Skill does **not** automatically publish or install it as a native ChatGPT plugin; the available installation path depends on the ChatGPT plugin/developer capabilities enabled for your account.
