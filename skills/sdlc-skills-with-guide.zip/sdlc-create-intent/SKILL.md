---
name: sdlc-create-intent
description: Capture a new feature, bug, refactor, technical-debt item, or improvement as a focused, reviewable intent.md. Use when the user wants to start a software change, clarify the problem and desired outcome, or revise an existing intent before specification. Do not design or implement the solution.
---

# Create intent

## Purpose and boundaries

Turn an informal request into a concise, standalone statement of **why** a change is needed and **what outcome** is sought. The output is the input to `sdlc-create-spec` (which defines testable system behavior), followed by planning and implementation. An intent is not a specification, design, task list, or implementation plan.

## Inputs and destination

Use the user's request and any relevant context they supplied. If working in a repository, read applicable repository instructions and inspect only the context necessary to understand the problem and existing behavior. Do not require a connection to an issue tracker.

Create or update exactly one work-item artifact at `sdlc/<work-item>/intent.md`, where `<work-item>` is a short, stable, lowercase kebab-case slug. Prefix with an existing work-item ID if one is provided (for example, `6545-pipeline-refactoring`). Reuse the existing work-item directory when revising an intent; do not create a second directory for the same change. If operating in ChatGPT without access to a writable repository, present the Markdown content for review or produce the file as a downloadable artifact if file creation is available; do not claim it has been committed or installed.

## Workflow

1. **Identify the request type and underlying need.** Accept feature ideas, bugs, improvements, refactors, and technical debt, including requests phrased as a solution. For bugs, distinguish actual versus expected behavior and impact. For refactors and technical debt, capture the risk or limitation and behavior that must remain unchanged.
2. **Separate outcomes from suggested solutions.** Preserve user-stated technologies or implementation preferences as *proposed approaches* unless the user explicitly identifies them as binding constraints. Do not remove genuine requirements, including named platforms or compatibility obligations.
3. **Clarify only blocking ambiguity.** Use available conversation and repository context first. If a missing decision materially changes the problem, desired outcome, scope, or hard constraints, ask one short, focused question at a time. Otherwise make a modest, explicitly labeled assumption or record an open question. Never invent stakeholder approval, requirements, or facts.
4. **Define scope.** Capture the desired outcome, included and excluded work, affected users/systems when known, constraints, and observable success indicators. Flag likely scope expansion rather than adding it silently. Keep the artifact proportional to the request.
5. **Write or revise `intent.md`.** Make it readable without chat history. Preserve confirmed decisions when revising; distinguish newly proposed changes from approved scope. Do not create `spec.md`, `plan.md`, `tasks.md`, status files, or implementation code.
6. **Present for review.** Summarize the outcome and material assumptions or open questions. Ask the user to correct or approve the intent before the next stage. Do not mark it approved merely because the file exists. Once approved, `sdlc-create-spec` may consume it.

## Artifact template

Use only relevant sections; omit empty sections and avoid repetitive boilerplate.

```markdown
# Intent: <clear outcome-oriented title>

## Problem
<Current situation, who or what is affected, and why change is needed. For bugs: expected vs actual behavior.>

## Desired outcome
<What should be different after this work, without prescribing implementation.>

## Scope
<Included users, behavior, capabilities, or systems.>

## Non-goals
<Explicit exclusions, if needed to prevent scope creep.>

## Constraints
<Confirmed technical, security, business, or compatibility limitations.>

## Success indicators
<Observable signals that the outcome has been achieved; not technical task steps.>

## Assumptions and open questions
<Only material uncertainties, clearly labeled.>

## Proposed approaches (optional)
<User-suggested implementation ideas that are not yet binding requirements.>
```

## Quality check before handoff

- Is the problem and desired outcome clear to someone without the original conversation?
- Are scope, exclusions, and actual constraints distinguishable from proposed solutions?
- Are important assumptions and open questions visible rather than invented as facts?
- Does the artifact avoid architecture decisions, file-by-file changes, task lists, and implementation sequencing?
- Does it identify the correct existing work item and preserve previous approved decisions when revising?

## Example

User request: “Replace our validation library so bad API requests stop reaching business logic.”

Capture the problem (invalid requests reach business logic), desired outcome (invalid inputs rejected consistently at the API boundary), and any confirmed compatibility constraints. Record replacing the library as a proposed approach unless the user says that exact replacement is mandatory. Do not select a replacement library or describe code changes.
