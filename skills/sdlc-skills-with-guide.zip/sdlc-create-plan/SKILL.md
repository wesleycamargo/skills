---
name: sdlc-create-plan
description: Create or revise plan.md with implementation approach, ordered executable tasks, per-task validation, and a handover section based on an approved spec.md. Use after specification approval or when replanning is required. Do not modify production code or create tasks.md.
---

# Create implementation plan

## Purpose and boundary

Translate an **approved** `spec.md` into a repository-grounded implementation approach **and tasks in the same `plan.md`**. The plan answers **how** to deliver the spec and how each task is validated; execution belongs to `sdlc-execute-plan`.

## Inputs and output

Read `sdlc/<work-item>/spec.md`, `intent.md` for context, applicable repository instructions, source code, tests, dependencies, build/deployment conventions, and existing `plan.md` when replanning. Confirm the spec has been approved; existence alone does not imply approval. Write or update **only** `sdlc/<work-item>/plan.md` as the persistent SDLC artifact. Never create `tasks.md`, `status.md`, or `handover.md`.

## Workflow

1. Identify the active existing `sdlc/<work-item>/` directory; do not start a parallel work item for the same change.
2. Read spec and inspect the actual repository before choosing affected components, conventions, migration strategy, or validation commands. Do not invent file paths or build tools.
3. Design the smallest implementation approach satisfying the requirements, with relevant dependencies, compatibility needs, risks, and test strategy.
4. Break the approach into dependency-ordered, independently verifiable tasks. Keep tasks meaningful rather than logging every small edit. Reference spec requirement IDs when useful.
5. Include relevant testing, regression, and negative paths. Mark all new tasks `pending`; use a concise checkbox list and validation criteria per task.
6. Add a short initial `Handover` section (current, next, blockers, remaining validation). If revising an existing plan, **preserve accurate execution history and status**; never reset completed work or overwrite another agent's changes without reconciling repository state.
7. If planning reveals a requirement gap, conflict, or scope change, flag it for review and return to `sdlc-create-spec` as needed; do not silently rewrite the spec. Ask only a focused blocking question if necessary.
8. Present the plan for human review before implementation. Do not describe it as approved merely because it exists.

## Suggested plan.md shape

```markdown
# Implementation plan: <title>

## Approach
<Repository-specific implementation strategy and important constraints.>

## Tasks
### Task 1 — <meaningful change>
Status: pending
- [ ] <implementation step>
- [ ] <test or verification step>
Validation: <specific passing condition; test commands only if verified for this repo>

### Task 2 — <meaningful change>
Status: pending
- [ ] <implementation step>
Validation: <specific completion criterion>

## Risks and final validation
<Only relevant concerns, regression checks, and any pending external validation.>

## Handover
Current: Not started
Next: Task 1 — <title>
Blockers: None
Remaining validation: <final checks>
```

## Quality check and handoff

Every applicable requirement must be covered by planned work or a stated existing behavior with verification. Each task must have a meaningful completion test, and dependencies must be clear. Preserve approved scope and existing behavior requirements. Report the plan path, unresolved blockers, and readiness for approval. `sdlc-execute-plan` uses this same file as its execution tracker.
