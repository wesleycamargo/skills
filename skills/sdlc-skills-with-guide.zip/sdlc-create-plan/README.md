# sdlc-create-plan

Create or revise plan.md with implementation approach, ordered executable tasks, per-task validation, and a handover section based on an approved spec.md. Use after specification approval or when replanning is required. Do not modify production code or create tasks.md.

## Use

Ask a compatible coding agent to use `sdlc-create-plan` for the active `sdlc/<work-item>/` directory. Read `SKILL.md` for full instructions.

This is a portable Agent Skill package, **not an installed ChatGPT plugin**. Installing or registering it depends on the capabilities of the target agent or ChatGPT account.
