# AI-native SDLC skills — usage guide

Five reusable skills turn a software change request into an intent, a testable specification, an implementation plan, code and tests, and a validation outcome. Use them in sequence for a new change; for work already underway, start at the stage that needs attention.

> **Availability:** These are portable `SKILL.md` definitions, not automatically installed ChatGPT plugins. Make the skills available in your chosen agent environment, or provide the relevant skill instructions to ChatGPT. Slash commands shown below are *illustrative*: use your environment's actual skill-invocation syntax.

## The flow

```mermaid
flowchart TD
    A["Idea / bug / improvement"] --> B["sdlc-create-intent"]
    B --> C["intent.md — WHY"]
    C -->|Review and approve| D["sdlc-create-spec"]
    D --> E["spec.md — WHAT"]
    E -->|Review and approve| F["sdlc-create-plan"]
    F --> G["plan.md — HOW + tasks"]
    G -->|Review and approve| H["sdlc-execute-plan"]
    H --> I["Code + tests"]
    H --> J["Update progress and handover in plan.md"]
    I --> K["sdlc-validate-implementation"]
    J --> K
    K --> L{"Acceptance criteria verified?"}
    L -->|Yes| M["Ready for human review / PR"]
    L -->|No — implementation gap| H
    L -->|No — requirements gap| D
    J -.->|Resume with another agent| H
```

The review arrows represent decisions, not extra skills. If an artifact already exists and is approved, use it rather than generating it again.

## Which skill should I call?

| When | Skill | Input | Deliverable | Why the deliverable matters |
| --- | --- | --- | --- | --- |
| You have a new idea, bug, refactor, or technical-debt request | `sdlc-create-intent` | Your initial request and relevant context | `sdlc/<work-item>/intent.md` | Captures the underlying problem, intended outcome, scope, and real constraints without prematurely choosing an implementation. |
| You have reviewed and approved an intent | `sdlc-create-spec` | `intent.md` and relevant repository context | `sdlc/<work-item>/spec.md` | States observable behavior, requirements, contracts, constraints, and testable acceptance criteria. |
| You have approved the specification | `sdlc-create-plan` | `spec.md`, supporting `intent.md`, repository | `sdlc/<work-item>/plan.md` | Explains the implementation approach, ordered executable tasks, risks, and validation approach. Tasks are *inside* the plan. |
| The plan is ready, or an agent needs to resume | `sdlc-execute-plan` | `spec.md`, `plan.md`, repository state | Code, tests, and updated `plan.md` | Implements the approved behavior and records just enough progress and handover context for the next agent. |
| Implementation is ready for an independent check | `sdlc-validate-implementation` | All three artifacts plus code and test results | A concise passed / failed / blocked result; correct task state in `plan.md` if necessary | Checks actual evidence against acceptance criteria and identifies unfinished, untested, or out-of-scope work. |

**Artifact boundaries:** `intent.md` = **why**; `spec.md` = **what**; `plan.md` = **how, tasks, progress, handover**. The code and tests are implementation outputs; validation is reported as a result, not a fourth SDLC document.

## Where do the files go?

```text
.ai/
└── skills/
    ├── sdlc-create-intent/SKILL.md
    ├── sdlc-create-spec/SKILL.md
    ├── sdlc-create-plan/SKILL.md
    ├── sdlc-execute-plan/SKILL.md
    └── sdlc-validate-implementation/SKILL.md

sdlc/
└── 6545-pipeline-refactoring/
    ├── intent.md
    ├── spec.md
    └── plan.md
```

Store skill *instructions* in your agent's supported skills location. The `.ai/skills/` layout above is the canonical template-repository convention, but individual agent products may require a different discovery path. Store the *work-item artifacts* in `sdlc/<work-item>/`. Use a stable lowercase kebab-case work-item slug; prefix an existing issue ID if available, but do not invent or require one. You do not need `tasks.md`, `status.md`, or `handover.md`.

## Start a new change: practical example

The example prompts below assume your agent can locate the five installed skills. Replace `/skill-name` with the invocation mechanism your agent supports.

**1. Capture the need.**

```text
/sdlc-create-intent
Our API accepts invalid customer IDs and fails downstream. Capture an intent
for rejecting invalid requests at the API boundary.
```

Review the resulting `sdlc/api-input-validation/intent.md`. Confirm that it describes the *problem and desired outcome*, not an unapproved library or code-level solution.

**2. Specify behavior.**

```text
/sdlc-create-spec
Create the specification for sdlc/api-input-validation/ based on its
approved intent.md and the existing API contracts.
```

Review `spec.md` for concrete requirements, error behavior, compatibility constraints, and acceptance criteria. If scope has changed, revise the intent before approving the new spec.

**3. Plan the implementation and tasks.**

```text
/sdlc-create-plan
Plan the approved specification in sdlc/api-input-validation/.
Inspect the repository and put the approach and executable tasks in plan.md.
```

Review `plan.md` before code changes. It should identify affected areas, task dependencies, and the checks needed to mark work complete.

**4. Implement and keep lightweight progress.**

```text
/sdlc-execute-plan
Implement sdlc/api-input-validation/ using its approved spec.md and plan.md.
Update task status and the short handover section in plan.md at meaningful milestones.
```

A concise in-progress task might look like:

```markdown
### Task 2 — Validate customer IDs
Status: in-progress
- [x] Reject malformed IDs
- [ ] Cover unknown IDs
Validation: malformed-ID tests passed; unknown-ID tests pending

## Handover
Current: Task 2
Next: Add unknown-ID handling and tests
Blockers: None
```

Do not log every edit or command. Mark a task **completed only after its task-level validation criteria pass**.

**5. Validate the result.**

```text
/sdlc-validate-implementation
Validate sdlc/api-input-validation/ against intent.md, spec.md, plan.md,
the actual code changes, and available test evidence.
```

The skill reports **passed**, **failed**, or **blocked**. A failed *implementation* check goes back to `sdlc-execute-plan`; a requirements or scope gap goes back to the relevant upstream artifact for review. A blocked check must state what could not be verified; it is not a pass.

## Resume work with a different agent

Give the new agent access to the same repository and invoke:

```text
/sdlc-execute-plan
Resume sdlc/api-input-validation/. Read spec.md and plan.md, compare the
recorded statuses and handover with the repository state, then continue the
next incomplete task. Do not overwrite existing uncommitted changes.
```

The agent should check the current code and available test results before trusting the recorded progress. Git shows *what changed*; `plan.md` records *what remains, what is blocked, and what to do next*. Previous chat history should not be necessary.

## If you need to change something midstream

| Situation | Action |
| --- | --- |
| The desired outcome or scope changes | Revisit `sdlc-create-intent`, then update downstream artifacts as needed. |
| A requirement or acceptance criterion is missing or wrong | Revisit `sdlc-create-spec`, review the update, then reconcile `plan.md`. |
| Only technical approach, sequencing, or task breakdown changes | Revisit `sdlc-create-plan`; preserve verified execution progress when revising an active plan. |
| Implementation is interrupted | Resume with `sdlc-execute-plan` using the existing artifacts and repository state. |
| Validation finds missing or failing code/tests | Return findings to `sdlc-execute-plan`, then validate again. |

A rough Azure DevOps analogy is **Feature ≈ intent**, **User Story/PBI ≈ spec**, and **Tasks ≈ tasks inside plan**. It is a mental model, not a mandatory one-to-one mapping.

## Using these files in ChatGPT

This package provides skill definitions and a workflow guide. **Uploading a ZIP or saving files to your ChatGPT Library does not install native ChatGPT plugins.** When a compatible plugin-development or skill-registration mechanism is available, follow its documented installation process. Until then, you can provide the relevant `SKILL.md` to ChatGPT as instructions for a stage and work with the `sdlc/<work-item>/` artifacts in an accessible repository or as downloadable files. Do not assume ChatGPT can modify your repository without an authorized integration.
