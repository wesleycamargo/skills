# sdlc-validate-implementation

Independently assess code and tests against intent.md, spec.md, plan.md, acceptance criteria, and actual repository state. Use after implementation or after remediation; report Passed, Failed, or Blocked and update incorrect statuses inside plan.md. Do not create a separate validation report.

## Use

Ask a compatible coding agent to use `sdlc-validate-implementation` for the active `sdlc/<work-item>/` directory. Read `SKILL.md` for full instructions.

This is a portable Agent Skill package, **not an installed ChatGPT plugin**. Installing or registering it depends on the capabilities of the target agent or ChatGPT account.
