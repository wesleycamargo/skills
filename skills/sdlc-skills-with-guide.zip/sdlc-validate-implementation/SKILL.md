---
name: sdlc-validate-implementation
description: Independently assess code and tests against intent.md, spec.md, plan.md, acceptance criteria, and actual repository state. Use after implementation or after remediation; report Passed, Failed, or Blocked and update incorrect statuses inside plan.md. Do not create a separate validation report.
---

# Validate implementation

## Purpose and independence

Verify **actual** implementation against the approved intent, specification, and execution plan; do not rely only on the implementation agent's self-reported completion. This skill may be run by a different agent. Validation is a check, **not** permission to silently modify requirements or implement unrelated improvements.

## Inputs and output

Read the existing `sdlc/<work-item>/intent.md`, `spec.md`, `plan.md`, relevant repository instructions, current code and Git diff, tests, and available build/deployment evidence. Produce a concise user-facing validation outcome: `Passed`, `Failed`, or `Blocked`. There is **no separate validation report file**. Update `plan.md` only if task status, validation information, or handover needs correction, and preserve the original planning content.

## Workflow

1. Establish approved scope and acceptance criteria from intent/spec; inventory plan tasks and their statuses. Inspect actual changes and check that implementation matches stated progress.
2. Trace each applicable requirement and acceptance criterion to concrete implementation and test evidence. Include relevant expected behavior, error/boundary conditions, compatibility and regression obligations, security, and operational constraints.
3. Run relevant automated tests, build/static checks, or contract/integration checks when feasible. Accurately distinguish executed-and-passed, executed-and-failed, not run, and unavailable checks. Never claim that code presence alone proves acceptance.
4. Detect incomplete tasks, unintended behavior, scope expansion, missing evidence, weakened tests, and regressions. Distinguish implementation failures from environmental blockers.
5. If `plan.md` inaccurately claims a task is completed, correct its status (`pending`, `in-progress`, or `blocked` as appropriate), capture a brief reason, and update the concise `## Handover` with a specific next action and remaining validation. Do not create another tracking file.
6. Return `Passed` only if all required acceptance criteria have sufficient evidence and required validation has succeeded; `Failed` if relevant criteria are unmet; `Blocked` if decisive verification cannot be performed. Do not conflate “not tested” with “passed.”

## Output format

```text
Outcome: Passed | Failed | Blocked
Scope: <work item and revision / state checked>
Verified: <requirements / criteria and supporting test or code evidence>
Tests: <commands and results; explicitly list not-run checks>
Findings: <specific gaps, failures, or 'None'>
Next: <action for review or remediation>
```

Keep the report proportionate; group trivial passes. If remediation is required, give executable findings to `sdlc-execute-plan` and identify spec changes that must return to `sdlc-create-spec` for review rather than silently changing acceptance criteria. Preserve implementation code unless explicitly authorized to correct it. Do not invent external approvals, successful tests, or repository access.
