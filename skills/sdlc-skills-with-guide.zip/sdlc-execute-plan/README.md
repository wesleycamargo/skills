# sdlc-execute-plan

Execute an approved plan.md, implement and test each task, and record lightweight progress and agent handover in that same plan.md. Use for implementation or resuming interrupted implementation. Do not create extra tracking files or silently expand scope.

## Use

Ask a compatible coding agent to use `sdlc-execute-plan` for the active `sdlc/<work-item>/` directory. Read `SKILL.md` for full instructions.

This is a portable Agent Skill package, **not an installed ChatGPT plugin**. Installing or registering it depends on the capabilities of the target agent or ChatGPT account.
