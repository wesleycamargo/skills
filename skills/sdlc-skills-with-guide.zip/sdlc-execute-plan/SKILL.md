---
name: sdlc-execute-plan
description: Execute an approved plan.md, implement and test each task, and record lightweight progress and agent handover in that same plan.md. Use for implementation or resuming interrupted implementation. Do not create extra tracking files or silently expand scope.
---

# Execute implementation plan

## Purpose

Implement an **approved** `plan.md` against `spec.md`; keep a future agent able to resume from `plan.md` plus repository state without past chat history. All persistent SDLC progress belongs **inside `sdlc/<work-item>/plan.md`**. Source code and tests are normal implementation outputs, not new SDLC artifacts.

## Inputs and preparation

1. Read the existing `sdlc/<work-item>/spec.md`, `plan.md`, relevant intent context, and repository instructions. Confirm plan approval or seek it before executing an unapproved plan.
2. Inspect Git status, current code, tests, and the plan's task statuses / handover. Respect uncommitted work and existing changes; never overwrite another agent's work.
3. If resuming, reconcile `plan.md` with repository reality and available test evidence before trusting a recorded completion. Note discrepancies briefly and correct status as needed; avoid repeating genuinely completed work.

## Execute and track

- Work through dependency-ordered tasks; keep changes within the approved spec and approved plan. Preserve required existing behavior, reuse established repository patterns, and include suitable unit, negative-path, integration, and regression tests.
- At meaningful milestones run relevant tests and record their actual results. Never claim tests passed if not run. A task is `completed` **only when its stated validation criteria are met**; otherwise leave `in-progress` or `blocked` with the reason.
- Keep task status vocabulary exactly: `pending`, `in-progress`, `completed`, `blocked`. Mark checklist items complete only when true.
- Update `plan.md` after a **meaningful** milestone, task status change, blocker, important decision/deviation, or validation result. Do not log individual commands, every file edit, or facts that can be recovered from Git.
- Keep `## Handover` short and current: active/last task, **exact next action**, blockers, and outstanding validation. This must be usable by another agent without conversation history.
- If new work appears, distinguish necessary in-scope work from optional improvement, technical debt, and future work. Add only clearly in-scope required tasks; flag spec changes or unapproved scope for review. Do not silently change requirements.
- If implementation cannot proceed safely, mark the task `blocked` and document the smallest actionable unblock request. Continue other independent, approved tasks where feasible.

## Minimal status example

```markdown
### Task 3 — Permission validation
Status: in-progress
- [x] Validate View permission
- [ ] Validate Queue permission
- [ ] Add negative-path test
Validation: unit tests passed; integration pending

## Handover
Current: Task 3 — Permission validation
Next: Add Queue permission validation and negative-path test
Blockers: None
Remaining validation: integration pipeline
```

## Finish / handoff

Cross-check implemented behavior against `spec.md`, run available relevant tests, and leave truthful task statuses and a concise handover. Do not announce final acceptance solely because tasks are checked: `sdlc-validate-implementation` independently checks the outcome. Report code/test changes, results, incomplete tasks, and blockers briefly. Do not create `tasks.md`, `status.md`, `handover.md`, `implementation.md`, or a separate progress artifact.
