---
name: sdlc-create-spec
description: Turn an approved intent.md into a testable spec.md defining required behavior and acceptance criteria. Use after intent review, when refining existing requirements, or when a specification needs correction. Do not write implementation tasks or code.
---

# Create specification

## Purpose and boundary

Translate an **approved** `intent.md` into a precise description of **what** the system must do. A spec describes observable outcomes, behavior, contracts, constraints, and acceptance criteria. `sdlc-create-plan` later decides **how** the repository will change. Do not implement code or generate tasks here.

## Inputs and output

- Required: `sdlc/<work-item>/intent.md` and confirmation it is approved for specification. A file existing is not evidence of approval. If approval is not established, present the intent for review before treating it as authoritative.
- Context: applicable repository instructions, existing behavior, public interfaces, tests, security/architecture conventions as relevant. Inspect only what improves the specification.
- Write only `sdlc/<work-item>/spec.md` in the **same existing work-item directory**. If working outside a writable repository, provide the Markdown or downloadable file and state that it was not written to a repository.
- Revisions: update the existing spec rather than creating another filename. Preserve approved requirements and flag proposed changes to intent or scope for review.

## Workflow

1. Read the intent and relevant repository rules; identify goals, non-goals, binding constraints, and proposed approaches that are *not* binding constraints.
2. Inspect existing behavior, interfaces, integration contracts, and tests as needed. Do not assume the current implementation is correct merely because it exists.
3. Translate each outcome into observable, testable requirements. Include relevant normal, error, boundary, and compatibility behavior. Add security/operational/performance constraints only when material; avoid invented thresholds.
4. Assign stable identifiers (for example `FR-1`, `FR-2`) when they improve traceability. State contract details only to the degree they are actually required, not speculative implementation decisions.
5. Clarify **only blocking** uncertainties using one focused question at a time; otherwise record explicit assumptions or open questions. Do not silently resolve conflicting requirements or expand scope.
6. Write or revise `spec.md`; present material decisions and assumptions for human review before it becomes the basis of planning.

## Suggested artifact shape

Keep the document proportional to change size; omit sections that do not apply.

```markdown
# Specification: <title>

## Context and scope
<Brief reference to intent; goals, exclusions, and confirmed constraints.>

## Requirements
- FR-1: <Observable, unambiguous behavior.>
- FR-2: <Expected failure or edge-case behavior, if relevant.>

## Interfaces and contracts
<Externally observable inputs, outputs, schemas, events, and invariants when relevant.>

## Compatibility and nonfunctional requirements
<Only applicable security, operations, performance, or behavior-preservation constraints.>

## Acceptance criteria
- [ ] AC-1 (FR-1): <Evidence-producing testable outcome.>

## Assumptions and open questions
<Only material unknowns; mark blocking questions clearly.>
```

## Hard boundaries and quality check

- `intent.md` explains **why and desired outcome**; `spec.md` defines **what must hold**; `plan.md` covers **how, where, and in what order**.
- No file-by-file edit instructions, task checklist for implementation, code changes, or unapproved scope additions in the spec.
- No vague acceptance criteria such as “works correctly”; criteria must be verifiable, including relevant failure cases.
- Cross-check the spec against the intent: every new requirement needs an intent-backed justification; contradictions require review rather than silent reinterpretation.
- If a proposed implementation technology from the intent is not a confirmed constraint, do not silently turn it into one.

## Handoff

Report the spec path, a short summary of requirements, and any blocking open decisions. `sdlc-create-plan` may consume the spec after approval.
