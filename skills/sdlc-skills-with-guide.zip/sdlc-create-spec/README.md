# sdlc-create-spec

Turn an approved intent.md into a testable spec.md defining required behavior and acceptance criteria. Use after intent review, when refining existing requirements, or when a specification needs correction. Do not write implementation tasks or code.

## Use

Ask a compatible coding agent to use `sdlc-create-spec` for the active `sdlc/<work-item>/` directory. Read `SKILL.md` for full instructions.

This is a portable Agent Skill package, **not an installed ChatGPT plugin**. Installing or registering it depends on the capabilities of the target agent or ChatGPT account.
